"""
E-commerce Customer Service Chatbot
A simple chatbot for handling common customer service queries in an e-commerce platform.
"""

import re
import json
import random
from datetime import datetime, timedelta
from typing import Dict, List, Tuple


class EcommerceChatbot:
    def __init__(self):
        self.user_context = {}
        self.load_data()
        self.init_patterns()
    
    def load_data(self):
        """Load mock data for orders, products, and customers"""
        # Mock order data
        self.orders = {
            "12345": {
                "id": "12345",
                "status": "shipped",
                "items": ["Wireless Headphones", "Phone Case"],
                "total": 89.99,
                "tracking": "TRK123456789",
                "estimated_delivery": "2025-10-10"
            },
            "67890": {
                "id": "67890",
                "status": "processing",
                "items": ["Laptop Stand", "USB Cable"],
                "total": 45.50,
                "tracking": None,
                "estimated_delivery": "2025-10-12"
            },
            "11111": {
                "id": "11111",
                "status": "delivered",
                "items": ["Coffee Mug", "Notebook"],
                "total": 25.99,
                "tracking": "TRK987654321",
                "estimated_delivery": "2025-10-05"
            }
        }
        
        # Mock product data
        self.products = {
            "wireless headphones": {
                "name": "Wireless Headphones",
                "price": 59.99,
                "description": "High-quality wireless headphones with noise cancellation",
                "in_stock": True,
                "rating": 4.5
            },
            "laptop stand": {
                "name": "Adjustable Laptop Stand",
                "price": 35.99,
                "description": "Ergonomic laptop stand with adjustable height",
                "in_stock": True,
                "rating": 4.2
            },
            "phone case": {
                "name": "Protective Phone Case",
                "price": 19.99,
                "description": "Durable phone case with drop protection",
                "in_stock": False,
                "rating": 4.0
            }
        }
        
        # Return policy and FAQ
        self.policies = {
            "return_policy": "You can return items within 30 days of purchase. Items must be in original condition.",
            "shipping_policy": "Standard shipping takes 3-5 business days. Express shipping takes 1-2 business days.",
            "warranty": "Most products come with a 1-year manufacturer warranty."
        }
    
    def init_patterns(self):
        """Initialize intent recognition patterns"""
        self.intent_patterns = {
            "greeting": [
                r"\b(hi|hello|hey|good morning|good afternoon|good evening)\b",
                r"\bwhat's up\b",
                r"\bhowdy\b"
            ],
            "order_status": [
                r"\border.*status\b",
                r"\btrack.*order\b",
                r"\bwhere.*order\b",
                r"\bshipment\b",
                r"\bdelivery\b",
                r"\border.*(\d+)\b"
            ],
            "return_request": [
                r"\breturn\b",
                r"\brefund\b",
                r"\bexchange\b",
                r"\bcancel.*order\b"
            ],
            "product_inquiry": [
                r"\bproduct\b",
                r"\bitem\b",
                r"\bprice\b",
                r"\bavailable\b",
                r"\bin stock\b",
                r"\bspecifications\b"
            ],
            "shipping_info": [
                r"\bshipping\b",
                r"\bdelivery time\b",
                r"\bhow long\b",
                r"\bwhen.*arrive\b"
            ],
            "help": [
                r"\bhelp\b",
                r"\bassist\b",
                r"\bsupport\b",
                r"\bwhat.*do\b"
            ],
            "goodbye": [
                r"\bbye\b",
                r"\bgoodbye\b",
                r"\bsee you\b",
                r"\btalk later\b",
                r"\bthanks\b",
                r"\bthank you\b"
            ]
        }
    
    def extract_order_id(self, message: str) -> str:
        """Extract order ID from user message"""
        # Look for patterns like "order 12345" or just "12345"
        patterns = [
            r"\border\s*[#:]?\s*(\d+)",
            r"\b(\d{5})\b",  # 5-digit order ID
            r"#(\d+)"
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return match.group(1)
        return None
    
    def recognize_intent(self, message: str) -> str:
        """Recognize user intent from message"""
        message_lower = message.lower()
        
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message_lower):
                    return intent
        
        return "unknown"
    
    def handle_greeting(self, message: str) -> str:
        """Handle greeting messages"""
        greetings = [
            "Hello! Welcome to our customer service. How can I help you today?",
            "Hi there! I'm here to assist you with your orders, products, and any questions you might have.",
            "Good day! How may I assist you with your shopping experience?"
        ]
        return random.choice(greetings)
    
    def handle_order_status(self, message: str) -> str:
        """Handle order status inquiries"""
        order_id = self.extract_order_id(message)
        
        if not order_id:
            return ("I'd be happy to help you check your order status! "
                   "Could you please provide your order number? It should be a 5-digit number.")
        
        if order_id in self.orders:
            order = self.orders[order_id]
            response = f"Here's your order #{order_id} status:\n\n"
            response += f"📦 Status: {order['status'].title()}\n"
            response += f"💰 Total: ${order['total']}\n"
            response += f"📋 Items: {', '.join(order['items'])}\n"
            
            if order['tracking']:
                response += f"🚚 Tracking: {order['tracking']}\n"
            
            if order['status'] == 'shipped':
                response += f"📅 Estimated delivery: {order['estimated_delivery']}\n"
                response += "Your order is on its way!"
            elif order['status'] == 'processing':
                response += f"📅 Estimated shipping: {order['estimated_delivery']}\n"
                response += "Your order is being prepared for shipment."
            elif order['status'] == 'delivered':
                response += "✅ Your order has been delivered!"
            
            return response
        else:
            return (f"I couldn't find an order with number {order_id}. "
                   "Please double-check your order number or contact us if you need further assistance.")
    
    def handle_return_request(self, message: str) -> str:
        """Handle return and refund requests"""
        return (f"I can help you with returns! Here's our return policy:\n\n"
                f"📋 {self.policies['return_policy']}\n\n"
                f"To start a return:\n"
                f"1. Go to 'My Orders' in your account\n"
                f"2. Select the item you want to return\n"
                f"3. Choose your reason for return\n"
                f"4. Print the prepaid return label\n\n"
                f"Would you like me to help you with a specific order return?")
    
    def handle_product_inquiry(self, message: str) -> str:
        """Handle product-related questions"""
        # Try to find mentioned products
        message_lower = message.lower()
        found_products = []
        
        for product_key, product_info in self.products.items():
            if product_key in message_lower or product_info['name'].lower() in message_lower:
                found_products.append(product_info)
        
        if found_products:
            response = "Here's information about the product(s) you asked about:\n\n"
            for product in found_products:
                response += f"🔹 {product['name']}\n"
                response += f"💰 Price: ${product['price']}\n"
                response += f"📝 {product['description']}\n"
                response += f"⭐ Rating: {product['rating']}/5\n"
                response += f"📦 Stock: {'✅ In Stock' if product['in_stock'] else '❌ Out of Stock'}\n\n"
            return response
        else:
            return ("I'd be happy to help you find product information! "
                   "Could you tell me which specific product you're interested in? "
                   "You can also browse our full catalog on our website.")
    
    def handle_shipping_info(self, message: str) -> str:
        """Handle shipping and delivery questions"""
        return (f"Here's our shipping information:\n\n"
                f"📦 {self.policies['shipping_policy']}\n\n"
                f"Shipping costs:\n"
                f"• Standard shipping: $5.99 (FREE on orders over $50)\n"
                f"• Express shipping: $12.99\n"
                f"• Next-day delivery: $19.99\n\n"
                f"We ship Monday through Friday. Orders placed before 2 PM are processed the same day!")
    
    def handle_help(self, message: str) -> str:
        """Handle general help requests"""
        return ("I'm here to help! I can assist you with:\n\n"
                "🔹 Checking order status and tracking\n"
                "🔹 Product information and availability\n"
                "🔹 Returns and exchanges\n"
                "🔹 Shipping information\n"
                "🔹 General shopping questions\n\n"
                "Just type your question in natural language and I'll do my best to help!")
    
    def handle_goodbye(self, message: str) -> str:
        """Handle farewell messages"""
        farewells = [
            "Thank you for contacting us! Have a great day! 😊",
            "Goodbye! Feel free to reach out anytime you need assistance!",
            "Thanks for using our customer service. Happy shopping! 🛍️"
        ]
        return random.choice(farewells)
    
    def handle_unknown(self, message: str) -> str:
        """Handle unrecognized intents"""
        return ("I'm not sure I understand your question, but I'm here to help! "
                "You can ask me about:\n"
                "• Order status (just mention your order number)\n"
                "• Product information\n"
                "• Returns and refunds\n"
                "• Shipping details\n\n"
                "Could you rephrase your question or tell me what specific help you need?")
    
    def get_response(self, message: str) -> str:
        """Main method to get chatbot response"""
        intent = self.recognize_intent(message)
        
        intent_handlers = {
            "greeting": self.handle_greeting,
            "order_status": self.handle_order_status,
            "return_request": self.handle_return_request,
            "product_inquiry": self.handle_product_inquiry,
            "shipping_info": self.handle_shipping_info,
            "help": self.handle_help,
            "goodbye": self.handle_goodbye,
            "unknown": self.handle_unknown
        }
        
        handler = intent_handlers.get(intent, self.handle_unknown)
        return handler(message)


def main():
    """Simple command-line interface for testing the chatbot"""
    print("🛍️ E-commerce Customer Service Chatbot")
    print("=" * 50)
    print("Type 'quit' to exit\n")
    
    chatbot = EcommerceChatbot()
    
    while True:
        user_input = input("You: ").strip()
        
        if user_input.lower() in ['quit', 'exit', 'q']:
            print("Chatbot: Thank you for using our service! Goodbye! 👋")
            break
        
        if user_input:
            response = chatbot.get_response(user_input)
            print(f"Chatbot: {response}\n")


if __name__ == "__main__":
    main()